// Validation script for 24/7 remote access to Market Data Collector
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Configuration
const config = {
  baseUrl: process.env.NETLIFY_URL || 'https://market-data-collector.netlify.app',
  apiEndpoint: '/.netlify/functions',
  checkInterval: 15 * 60 * 1000, // 15 minutes
  logFile: path.join(__dirname, 'access_validation.log'),
  endpoints: [
    '/fetch-market-data',
    '/process-market-data',
    '/calculate-indicators',
    '/store-market-data',
    '/monitoring'
  ],
  testData: {
    'fetch-market-data': {
      exchange: 'binance',
      symbol: 'BTC/USDT',
      timeframe: '1h',
      startDate: '2025-03-01',
      endDate: '2025-03-31'
    },
    'process-market-data': {
      data: Array(10).fill().map((_, i) => ({
        timestamp: new Date(2025, 2, 1).getTime() + i * 60 * 60 * 1000,
        datetime: new Date(new Date(2025, 2, 1).getTime() + i * 60 * 60 * 1000).toISOString(),
        open: 50000 + Math.random() * 5000,
        high: 50000 + Math.random() * 7000,
        low: 50000 + Math.random() * 3000,
        close: 50000 + Math.random() * 5000,
        volume: 100 + Math.random() * 900
      })),
      options: {
        alignTimestamps: true,
        handleMissingValues: true
      }
    },
    'calculate-indicators': {
      data: Array(10).fill().map((_, i) => ({
        timestamp: new Date(2025, 2, 1).getTime() + i * 60 * 60 * 1000,
        datetime: new Date(new Date(2025, 2, 1).getTime() + i * 60 * 60 * 1000).toISOString(),
        open: 50000 + Math.random() * 5000,
        high: 50000 + Math.random() * 7000,
        low: 50000 + Math.random() * 3000,
        close: 50000 + Math.random() * 5000,
        volume: 100 + Math.random() * 900
      })),
      indicators: ['sma', 'ema']
    }
  }
};

// Initialize log file
function initLogFile() {
  if (!fs.existsSync(config.logFile)) {
    fs.writeFileSync(config.logFile, 'Timestamp,Endpoint,Status,ResponseTime,Message\n');
  }
}

// Log validation result
function logResult(endpoint, status, responseTime, message = '') {
  const timestamp = new Date().toISOString();
  const logEntry = `${timestamp},${endpoint},${status},${responseTime},${message}\n`;
  
  fs.appendFileSync(config.logFile, logEntry);
  console.log(`[${timestamp}] ${endpoint}: ${status} (${responseTime}ms) ${message}`);
}

// Check if site is accessible
async function checkSiteAccess() {
  const startTime = Date.now();
  try {
    const response = await axios.get(config.baseUrl);
    const responseTime = Date.now() - startTime;
    
    logResult('site', 'OK', responseTime);
    return true;
  } catch (error) {
    const responseTime = Date.now() - startTime;
    logResult('site', 'ERROR', responseTime, error.message);
    return false;
  }
}

// Check if API endpoint is accessible
async function checkApiEndpoint(endpoint) {
  const url = `${config.baseUrl}${config.apiEndpoint}${endpoint}`;
  const startTime = Date.now();
  
  try {
    // For OPTIONS request (CORS preflight)
    const optionsResponse = await axios({
      method: 'OPTIONS',
      url,
      headers: {
        'Origin': config.baseUrl,
        'Access-Control-Request-Method': 'POST'
      }
    });
    
    // For actual API test
    const testData = config.testData[endpoint.substring(1)] || {};
    const response = await axios.post(url, testData);
    
    const responseTime = Date.now() - startTime;
    logResult(endpoint, 'OK', responseTime);
    return true;
  } catch (error) {
    const responseTime = Date.now() - startTime;
    logResult(endpoint, 'ERROR', responseTime, error.message);
    return false;
  }
}

// Run all validation checks
async function runValidation() {
  console.log(`Starting validation at ${new Date().toISOString()}`);
  
  // Check site access
  const siteAccessible = await checkSiteAccess();
  
  // Check API endpoints
  const apiResults = [];
  for (const endpoint of config.endpoints) {
    const result = await checkApiEndpoint(endpoint);
    apiResults.push({ endpoint, result });
  }
  
  // Calculate success rate
  const successfulApiCalls = apiResults.filter(r => r.result).length;
  const totalApiCalls = apiResults.length;
  const successRate = (successfulApiCalls / totalApiCalls) * 100;
  
  console.log(`Validation complete. Success rate: ${successRate.toFixed(2)}%`);
  console.log(`Site accessible: ${siteAccessible}`);
  console.log(`API endpoints: ${successfulApiCalls}/${totalApiCalls} successful`);
  
  return {
    timestamp: new Date().toISOString(),
    siteAccessible,
    apiResults,
    successRate
  };
}

// Run continuous validation
function startContinuousValidation() {
  // Initialize log file
  initLogFile();
  
  // Run initial validation
  runValidation();
  
  // Schedule periodic validation
  setInterval(runValidation, config.checkInterval);
  
  console.log(`Continuous validation started. Checking every ${config.checkInterval / 60000} minutes.`);
  console.log(`Logs are being written to ${config.logFile}`);
}

// Generate validation report
async function generateReport(days = 7) {
  // Read log file
  const logContent = fs.readFileSync(config.logFile, 'utf8');
  const logLines = logContent.split('\n').filter(line => line.trim());
  
  // Skip header
  const dataLines = logLines.slice(1);
  
  // Parse log entries
  const entries = dataLines.map(line => {
    const [timestamp, endpoint, status, responseTime, message] = line.split(',');
    return {
      timestamp,
      endpoint,
      status,
      responseTime: parseInt(responseTime),
      message
    };
  });
  
  // Filter entries for the specified time period
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);
  
  const recentEntries = entries.filter(entry => 
    new Date(entry.timestamp) >= cutoffDate
  );
  
  // Calculate statistics
  const totalChecks = recentEntries.length;
  const successfulChecks = recentEntries.filter(entry => entry.status === 'OK').length;
  const overallSuccessRate = (successfulChecks / totalChecks) * 100;
  
  // Group by endpoint
  const endpointStats = {};
  recentEntries.forEach(entry => {
    if (!endpointStats[entry.endpoint]) {
      endpointStats[entry.endpoint] = {
        total: 0,
        successful: 0,
        avgResponseTime: 0,
        totalResponseTime: 0
      };
    }
    
    endpointStats[entry.endpoint].total++;
    if (entry.status === 'OK') {
      endpointStats[entry.endpoint].successful++;
    }
    endpointStats[entry.endpoint].totalResponseTime += entry.responseTime;
  });
  
  // Calculate per-endpoint statistics
  Object.keys(endpointStats).forEach(endpoint => {
    const stats = endpointStats[endpoint];
    stats.successRate = (stats.successful / stats.total) * 100;
    stats.avgResponseTime = stats.totalResponseTime / stats.total;
  });
  
  // Generate report
  const report = {
    generatedAt: new Date().toISOString(),
    period: `${days} days`,
    totalChecks,
    successfulChecks,
    overallSuccessRate,
    endpointStats
  };
  
  // Write report to file
  const reportFile = path.join(__dirname, `validation_report_${new Date().toISOString().split('T')[0]}.json`);
  fs.writeFileSync(reportFile, JSON.stringify(report, null, 2));
  
  console.log(`Report generated and saved to ${reportFile}`);
  
  return report;
}

// Main function
async function main() {
  const args = process.argv.slice(2);
  
  if (args.includes('--report')) {
    // Generate report mode
    const daysArg = args.find(arg => arg.startsWith('--days='));
    const days = daysArg ? parseInt(daysArg.split('=')[1]) : 7;
    
    await generateReport(days);
  } else {
    // Continuous validation mode
    startContinuousValidation();
  }
}

// Run the script
if (require.main === module) {
  main().catch(error => {
    console.error('Error in validation script:', error);
    process.exit(1);
  });
}

module.exports = {
  runValidation,
  generateReport
};
