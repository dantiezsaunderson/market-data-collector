# Market Data Collector - Netlify Hosted Application

## Overview

The Market Data Collector is a web-based application for collecting, processing, and visualizing historical market data for algorithmic trading. This application is hosted on Netlify with 24/7 remote access to all functions.

## Features

- **Data Collection**: Connect to cryptocurrency exchanges (Binance, Bybit, Coinbase, Kraken) to fetch OHLCV data
- **Data Processing**: Clean, preprocess, and normalize market data
- **Technical Analysis**: Calculate indicators like SMA, EMA, RSI, MACD, and more
- **Data Visualization**: Interactive charts for price data and technical indicators
- **Scheduled Jobs**: Automated data collection on hourly, daily, weekly, or monthly schedules
- **Cloud Storage**: Store and manage market data in Firebase
- **User Authentication**: Secure access with user accounts and authentication

## Architecture

The application follows a modern web architecture:

1. **Frontend**: React-based single-page application (SPA)
2. **Backend**: Serverless functions hosted on Netlify
3. **Storage**: Firebase Firestore and Storage for data persistence
4. **Authentication**: Firebase Authentication for user management
5. **Scheduled Tasks**: Netlify scheduled functions for automated data collection

## Getting Started

### Prerequisites

- Node.js 18 or higher
- npm or yarn
- Firebase account
- Netlify account

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/market-data-collector.git
   cd market-data-collector
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Set up environment variables:
   Create a `.env` file with the following variables:
   ```
   REACT_APP_FIREBASE_API_KEY=your_firebase_api_key
   REACT_APP_FIREBASE_AUTH_DOMAIN=your_firebase_auth_domain
   REACT_APP_FIREBASE_PROJECT_ID=your_firebase_project_id
   REACT_APP_FIREBASE_STORAGE_BUCKET=your_firebase_storage_bucket
   REACT_APP_FIREBASE_MESSAGING_SENDER_ID=your_firebase_messaging_sender_id
   REACT_APP_FIREBASE_APP_ID=your_firebase_app_id
   REACT_APP_API_BASE_URL=/.netlify/functions
   ```

4. Start the development server:
   ```
   npm start
   ```

5. Start the Netlify development environment:
   ```
   netlify dev
   ```

### Deployment

1. Build the application:
   ```
   npm run build
   ```

2. Deploy to Netlify:
   ```
   netlify deploy --prod
   ```

## Usage Guide

### Authentication

1. **Register**: Create a new account with email and password
2. **Login**: Access your account with your credentials
3. **Reset Password**: Recover your account if you forget your password

### Data Collection

1. Navigate to the Data Collection page
2. Select an exchange, symbol, timeframe, and date range
3. Click "Collect Data" to fetch market data
4. View the results and save to storage if desired

### Data Visualization

1. Navigate to the Data Visualization page
2. Select parameters (exchange, symbol, timeframe, date range)
3. Click "Load Data" to view the price chart
4. Switch between tabs to view different visualizations:
   - Price Chart: Candlestick chart with volume
   - Technical Indicators: View indicators like SMA, EMA, RSI
   - Volume Profile: Analyze volume distribution (coming soon)
   - Correlation Matrix: Compare multiple assets (coming soon)

### Scheduled Jobs

1. Navigate to the Data Management page
2. Click "Create New Job" to set up automated data collection
3. Configure job parameters:
   - Name and description
   - Schedule (hourly, daily, weekly, monthly)
   - Data source (exchange, symbol, timeframe)
   - Processing options
   - Storage options
4. Manage existing jobs:
   - View status and history
   - Pause/resume jobs
   - Edit job configuration
   - Delete jobs

### Data Management

1. Navigate to the Data Management page
2. View all collected datasets
3. Filter by symbol, timeframe, or format
4. Perform actions:
   - View dataset details
   - Download data
   - Delete datasets
5. Monitor storage usage and optimize if needed

## API Reference

### Netlify Functions

#### fetch-market-data

Fetches historical market data from cryptocurrency exchanges.

**Request:**
```json
{
  "exchange": "binance",
  "symbol": "BTC/USDT",
  "timeframe": "1h",
  "startDate": "2025-03-01",
  "endDate": "2025-03-31",
  "apiKey": "optional_api_key",
  "apiSecret": "optional_api_secret",
  "includeOrderbook": false,
  "includeTickers": false
}
```

**Response:**
```json
{
  "exchange": "binance",
  "symbol": "BTC/USDT",
  "timeframe": "1h",
  "startDate": "2025-03-01",
  "endDate": "2025-03-31",
  "dataPoints": 720,
  "ohlcv": [
    {
      "timestamp": 1614556800000,
      "datetime": "2025-03-01T00:00:00.000Z",
      "open": 45000.0,
      "high": 45500.0,
      "low": 44800.0,
      "close": 45200.0,
      "volume": 1250.5
    },
    // More data points...
  ]
}
```

#### process-market-data

Cleans and preprocesses market data.

**Request:**
```json
{
  "data": [
    // Array of OHLCV data objects
  ],
  "options": {
    "alignTimestamps": true,
    "handleMissingValues": true,
    "removeOutliers": true,
    "outlierThreshold": 3,
    "normalize": false
  }
}
```

**Response:**
```json
{
  "originalCount": 720,
  "processedCount": 720,
  "processingSteps": [
    "alignTimestamps",
    "handleMissingValues",
    "removeOutliers"
  ],
  "data": [
    // Processed OHLCV data objects
  ]
}
```

#### calculate-indicators

Calculates technical indicators for market data.

**Request:**
```json
{
  "data": [
    // Array of OHLCV data objects
  ],
  "indicators": ["sma", "ema", "rsi"],
  "parameters": {
    "smaPeriod": 20,
    "emaPeriod": 20,
    "rsiPeriod": 14,
    "combineWithData": true
  }
}
```

**Response:**
```json
{
  "originalData": [
    // Original OHLCV data
  ],
  "indicators": {
    "sma": [null, null, ..., 45100.0, 45200.0],
    "ema": [null, null, ..., 45150.0, 45180.0],
    "rsi": [null, null, ..., 58.5, 62.3]
  },
  "combinedData": [
    // OHLCV data with indicators added
  ]
}
```

#### store-market-data

Stores market data in Firebase.

**Request:**
```json
{
  "data": [
    // Array of OHLCV data objects
  ],
  "metadata": {
    "symbol": "BTC/USDT",
    "timeframe": "1h",
    "startDate": "2025-03-01",
    "endDate": "2025-03-31"
  },
  "options": {
    "storageMethod": "firestore",
    "format": "json"
  }
}
```

**Response:**
```json
{
  "success": true,
  "storageMethod": "firestore",
  "result": {
    "id": "dataset_uuid",
    "chunks": 2
  }
}
```

## Performance Optimization

The application includes several performance optimizations:

1. **Data Chunking**: Large datasets are processed in chunks to avoid UI freezing
2. **Memoization**: Expensive calculations are cached to avoid redundant processing
3. **Lazy Loading**: Components are loaded only when needed
4. **Virtualized Lists**: Only visible items are rendered for large lists
5. **Data Compression**: Data is compressed for efficient storage and transmission
6. **Web Workers**: Heavy computations are offloaded to background threads
7. **Chart Optimization**: Large datasets are sampled for efficient rendering

## Error Handling

The application includes a comprehensive error handling system:

1. **Custom Error Classes**: Structured error objects with metadata
2. **Error Categories**: API, Authentication, Data Processing, etc.
3. **Severity Levels**: Info, Warning, Error, Critical
4. **Logging**: Client-side and remote logging
5. **Error Boundaries**: React components for graceful UI error recovery
6. **Toast Notifications**: User-friendly error messages

## Security Considerations

1. **Authentication**: Firebase Authentication for secure user management
2. **Data Encryption**: Sensitive data is encrypted in transit and at rest
3. **API Keys**: Exchange API keys are stored securely and never exposed to clients
4. **Input Validation**: All user inputs are validated to prevent injection attacks
5. **CORS Protection**: API endpoints are protected with proper CORS headers
6. **Rate Limiting**: API requests are rate-limited to prevent abuse

## Monitoring and Maintenance

1. **Scheduled Jobs**: Automated data collection runs on predefined schedules
2. **Storage Cleanup**: Old data is automatically archived or deleted based on retention policies
3. **Error Monitoring**: Errors are logged and can be monitored for troubleshooting
4. **Performance Metrics**: Application performance is monitored for optimization opportunities

## Troubleshooting

### Common Issues

1. **Data Not Loading**:
   - Check your internet connection
   - Verify exchange API status
   - Check for rate limiting or IP restrictions

2. **Scheduled Jobs Not Running**:
   - Verify job status is "active"
   - Check for error messages in job history
   - Ensure Firebase credentials are valid

3. **Charts Not Rendering**:
   - Check if data is loaded correctly
   - Try reducing the date range for large datasets
   - Clear browser cache and reload

### Support

For additional support, please contact support@marketdatacollector.com or open an issue on GitHub.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- [CCXT](https://github.com/ccxt/ccxt) for cryptocurrency exchange connectivity
- [React](https://reactjs.org/) for the frontend framework
- [Material-UI](https://mui.com/) for the UI components
- [ApexCharts](https://apexcharts.com/) for interactive charts
- [Firebase](https://firebase.google.com/) for cloud storage and authentication
- [Netlify](https://www.netlify.com/) for hosting and serverless functions
