// API service for interacting with Netlify Functions
import axios from 'axios';

// Base URL for Netlify Functions
// In development, this would be the local Netlify dev server
// In production, this would be the deployed Netlify site URL
const BASE_URL = process.env.REACT_APP_API_BASE_URL || '/.netlify/functions';

/**
 * Service for interacting with market data API endpoints
 */
class MarketDataApiService {
  /**
   * Fetch market data from cryptocurrency exchanges
   * @param {Object} params - Parameters for data fetching
   * @param {string} params.exchange - Exchange name (binance, bybit, etc.)
   * @param {string} params.symbol - Trading pair symbol (e.g., BTC/USDT)
   * @param {string} params.timeframe - Timeframe interval (e.g., 1h, 4h, 1d)
   * @param {string} params.startDate - Start date in ISO format
   * @param {string} params.endDate - End date in ISO format
   * @param {string} [params.apiKey] - API key for authenticated requests
   * @param {string} [params.apiSecret] - API secret for authenticated requests
   * @param {boolean} [params.includeOrderbook] - Whether to include order book data
   * @param {boolean} [params.includeTickers] - Whether to include ticker data
   * @returns {Promise<Object>} Fetched market data
   */
  async fetchMarketData(params) {
    try {
      const response = await axios.post(`${BASE_URL}/fetch-market-data`, params);
      return response.data;
    } catch (error) {
      console.error('Error fetching market data:', error);
      throw this.handleApiError(error);
    }
  }

  /**
   * Process and clean market data
   * @param {Object} params - Parameters for data processing
   * @param {Array} params.data - Array of OHLCV data objects
   * @param {Object} [params.options] - Processing options
   * @param {boolean} [params.options.alignTimestamps] - Whether to align timestamps
   * @param {boolean} [params.options.handleMissingValues] - Whether to handle missing values
   * @param {boolean} [params.options.removeOutliers] - Whether to remove outliers
   * @param {number} [params.options.outlierThreshold] - Threshold for outlier detection
   * @param {boolean} [params.options.normalize] - Whether to normalize data
   * @returns {Promise<Object>} Processed market data
   */
  async processMarketData(params) {
    try {
      const response = await axios.post(`${BASE_URL}/process-market-data`, params);
      return response.data;
    } catch (error) {
      console.error('Error processing market data:', error);
      throw this.handleApiError(error);
    }
  }

  /**
   * Calculate technical indicators for market data
   * @param {Object} params - Parameters for indicator calculation
   * @param {Array} params.data - Array of OHLCV data objects
   * @param {Array} [params.indicators] - Array of indicator names to calculate
   * @param {Object} [params.parameters] - Parameters for indicator calculation
   * @returns {Promise<Object>} Calculated indicators
   */
  async calculateIndicators(params) {
    try {
      const response = await axios.post(`${BASE_URL}/calculate-indicators`, params);
      return response.data;
    } catch (error) {
      console.error('Error calculating indicators:', error);
      throw this.handleApiError(error);
    }
  }

  /**
   * Store market data in Firebase
   * @param {Object} params - Parameters for data storage
   * @param {Array} params.data - Array of OHLCV data objects
   * @param {Object} params.metadata - Metadata for the dataset
   * @param {Object} [params.options] - Storage options
   * @returns {Promise<Object>} Storage result
   */
  async storeMarketData(params) {
    try {
      const response = await axios.post(`${BASE_URL}/store-market-data`, params);
      return response.data;
    } catch (error) {
      console.error('Error storing market data:', error);
      throw this.handleApiError(error);
    }
  }

  /**
   * Handle API errors
   * @param {Error} error - Error object from axios
   * @returns {Error} Processed error
   */
  handleApiError(error) {
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      const serverError = new Error(
        error.response.data.message || 'Server error'
      );
      serverError.status = error.response.status;
      serverError.data = error.response.data;
      return serverError;
    } else if (error.request) {
      // The request was made but no response was received
      return new Error('No response from server. Please check your network connection.');
    } else {
      // Something happened in setting up the request that triggered an Error
      return new Error('Error setting up request: ' + error.message);
    }
  }
}

export default new MarketDataApiService();
