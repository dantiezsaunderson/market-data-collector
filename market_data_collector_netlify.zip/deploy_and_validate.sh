#!/bin/bash

# Final deployment and validation script for Market Data Collector on Netlify

echo "=========================================================="
echo "Market Data Collector - Final Deployment and Validation"
echo "=========================================================="

# Set up environment variables
export NETLIFY_AUTH_TOKEN="nfp_JP9Jo4eT7WBnCJg9vEThqqmwqbEdzHBr12ef"
export NETLIFY_SITE_NAME="market-data-collector"
export NODE_ENV="production"

# Create summary file
SUMMARY_FILE="deployment_summary.md"
echo "# Market Data Collector - Deployment Summary" > $SUMMARY_FILE
echo "**Date:** $(date)" >> $SUMMARY_FILE
echo "" >> $SUMMARY_FILE

echo "1. Running pre-deployment checks..."
echo "## 1. Pre-deployment Checks" >> $SUMMARY_FILE

# Check if Netlify CLI is installed
if ! command -v netlify &> /dev/null; then
    echo "Installing Netlify CLI..."
    npm install -g netlify-cli
    echo "- ✅ Netlify CLI installed" >> $SUMMARY_FILE
else
    echo "- ✅ Netlify CLI already installed" >> $SUMMARY_FILE
fi

# Check if required files exist
REQUIRED_FILES=(
    "package.json"
    "netlify.toml"
    "src/index.js"
    "netlify/functions/fetch-market-data.js"
    "netlify/functions/process-market-data.js"
    "netlify/functions/calculate-indicators.js"
    "netlify/functions/store-market-data.js"
    "netlify/functions/monitoring.js"
    "netlify/scheduled-functions/collect-market-data.js"
)

MISSING_FILES=0
for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        echo "❌ Missing required file: $file"
        echo "- ❌ Missing required file: $file" >> $SUMMARY_FILE
        MISSING_FILES=$((MISSING_FILES+1))
    fi
done

if [ $MISSING_FILES -eq 0 ]; then
    echo "All required files present."
    echo "- ✅ All required files present" >> $SUMMARY_FILE
else
    echo "Error: $MISSING_FILES required files are missing. Deployment aborted."
    echo "- ❌ $MISSING_FILES required files are missing. Deployment aborted." >> $SUMMARY_FILE
    exit 1
fi

echo "" >> $SUMMARY_FILE
echo "2. Installing dependencies..."
echo "## 2. Dependencies Installation" >> $SUMMARY_FILE

# Install dependencies
npm install
if [ $? -eq 0 ]; then
    echo "Dependencies installed successfully."
    echo "- ✅ Dependencies installed successfully" >> $SUMMARY_FILE
else
    echo "Error: Failed to install dependencies. Deployment aborted."
    echo "- ❌ Failed to install dependencies. Deployment aborted." >> $SUMMARY_FILE
    exit 1
fi

echo "" >> $SUMMARY_FILE
echo "3. Building application..."
echo "## 3. Application Build" >> $SUMMARY_FILE

# Build the application
npm run build
if [ $? -eq 0 ]; then
    echo "Application built successfully."
    echo "- ✅ Application built successfully" >> $SUMMARY_FILE
else
    echo "Error: Failed to build application. Deployment aborted."
    echo "- ❌ Failed to build application. Deployment aborted." >> $SUMMARY_FILE
    exit 1
fi

echo "" >> $SUMMARY_FILE
echo "4. Deploying to Netlify..."
echo "## 4. Netlify Deployment" >> $SUMMARY_FILE

# Deploy to Netlify
DEPLOY_OUTPUT=$(netlify deploy --prod --auth $NETLIFY_AUTH_TOKEN --site $NETLIFY_SITE_NAME --dir build)
DEPLOY_STATUS=$?

if [ $DEPLOY_STATUS -eq 0 ]; then
    echo "Application deployed successfully to Netlify."
    echo "- ✅ Application deployed successfully to Netlify" >> $SUMMARY_FILE
    
    # Extract deployment URL
    DEPLOY_URL=$(echo "$DEPLOY_OUTPUT" | grep -o 'https://[^ ]*' | head -1)
    echo "Deployment URL: $DEPLOY_URL"
    echo "- Deployment URL: $DEPLOY_URL" >> $SUMMARY_FILE
else
    echo "Error: Failed to deploy to Netlify. Deployment aborted."
    echo "- ❌ Failed to deploy to Netlify. Deployment aborted." >> $SUMMARY_FILE
    exit 1
fi

echo "" >> $SUMMARY_FILE
echo "5. Setting up environment variables..."
echo "## 5. Environment Variables Setup" >> $SUMMARY_FILE

# Set up environment variables in Netlify
netlify env:set FIREBASE_DATABASE_URL "https://market-data-collector.firebaseio.com" --auth $NETLIFY_AUTH_TOKEN
netlify env:set FIREBASE_STORAGE_BUCKET "market-data-collector.appspot.com" --auth $NETLIFY_AUTH_TOKEN
netlify env:set NETLIFY_URL "$DEPLOY_URL" --auth $NETLIFY_AUTH_TOKEN

echo "Environment variables set up successfully."
echo "- ✅ Environment variables set up successfully" >> $SUMMARY_FILE

echo "" >> $SUMMARY_FILE
echo "6. Enabling scheduled functions..."
echo "## 6. Scheduled Functions Setup" >> $SUMMARY_FILE

# Enable scheduled functions
netlify functions:create --name collect-market-data --scheduled "0 * * * *" --auth $NETLIFY_AUTH_TOKEN
if [ $? -eq 0 ]; then
    echo "Scheduled functions enabled successfully."
    echo "- ✅ Scheduled functions enabled successfully" >> $SUMMARY_FILE
else
    echo "Warning: Failed to enable scheduled functions. Manual setup may be required."
    echo "- ⚠️ Failed to enable scheduled functions. Manual setup may be required." >> $SUMMARY_FILE
fi

echo "" >> $SUMMARY_FILE
echo "7. Validating 24/7 remote access..."
echo "## 7. Remote Access Validation" >> $SUMMARY_FILE

# Run initial validation
echo "Running initial access validation..."
node validate_access.js --single-run
if [ $? -eq 0 ]; then
    echo "Initial access validation successful."
    echo "- ✅ Initial access validation successful" >> $SUMMARY_FILE
else
    echo "Warning: Initial access validation failed. Manual verification recommended."
    echo "- ⚠️ Initial access validation failed. Manual verification recommended." >> $SUMMARY_FILE
fi

echo "" >> $SUMMARY_FILE
echo "8. Setting up continuous monitoring..."
echo "## 8. Continuous Monitoring Setup" >> $SUMMARY_FILE

# Set up cron job for continuous monitoring
CRON_JOB="0 */6 * * * cd $(pwd) && node validate_access.js >> validation.log 2>&1"
(crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
if [ $? -eq 0 ]; then
    echo "Continuous monitoring cron job set up successfully."
    echo "- ✅ Continuous monitoring cron job set up successfully" >> $SUMMARY_FILE
    echo "- Validation will run every 6 hours" >> $SUMMARY_FILE
else
    echo "Warning: Failed to set up continuous monitoring cron job. Manual setup recommended."
    echo "- ⚠️ Failed to set up continuous monitoring cron job. Manual setup recommended." >> $SUMMARY_FILE
fi

echo "" >> $SUMMARY_FILE
echo "## 9. Summary" >> $SUMMARY_FILE
echo "The Market Data Collector application has been successfully deployed to Netlify with 24/7 remote access." >> $SUMMARY_FILE
echo "" >> $SUMMARY_FILE
echo "### Access Information" >> $SUMMARY_FILE
echo "- **Application URL:** $DEPLOY_URL" >> $SUMMARY_FILE
echo "- **API Base URL:** $DEPLOY_URL/.netlify/functions" >> $SUMMARY_FILE
echo "- **Monitoring Dashboard:** $DEPLOY_URL/dashboard" >> $SUMMARY_FILE
echo "" >> $SUMMARY_FILE
echo "### Next Steps" >> $SUMMARY_FILE
echo "1. Verify application functionality through the web interface" >> $SUMMARY_FILE
echo "2. Set up Firebase authentication for the first admin user" >> $SUMMARY_FILE
echo "3. Configure email notifications for the monitoring system" >> $SUMMARY_FILE
echo "4. Review the first validation report after 24 hours" >> $SUMMARY_FILE
echo "" >> $SUMMARY_FILE
echo "### Support" >> $SUMMARY_FILE
echo "For any issues or questions, please refer to the documentation or contact support." >> $SUMMARY_FILE

echo "=========================================================="
echo "Deployment and validation complete!"
echo "=========================================================="
echo "Application URL: $DEPLOY_URL"
echo "Summary saved to: $SUMMARY_FILE"
echo ""
echo "Next steps:"
echo "1. Verify application functionality through the web interface"
echo "2. Set up Firebase authentication for the first admin user"
echo "3. Configure email notifications for the monitoring system"
echo "4. Review the first validation report after 24 hours"
echo ""
echo "For continuous validation, a cron job has been set up to run every 6 hours."
echo "Validation logs will be saved to validation.log"
