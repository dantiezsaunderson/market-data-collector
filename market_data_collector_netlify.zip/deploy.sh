# Netlify deployment script for Market Data Collector application

# Set up environment variables for deployment
export NETLIFY_AUTH_TOKEN="nfp_JP9Jo4eT7WBnCJg9vEThqqmwqbEdzHBr12ef"
export NETLIFY_SITE_NAME="market-data-collector"

# Install Netlify CLI if not already installed
if ! command -v netlify &> /dev/null; then
    echo "Installing Netlify CLI..."
    npm install -g netlify-cli
fi

# Install dependencies
echo "Installing dependencies..."
npm install

# Build the application
echo "Building application..."
npm run build

# Deploy to Netlify
echo "Deploying to Netlify..."
netlify deploy --prod --auth $NETLIFY_AUTH_TOKEN --site $NETLIFY_SITE_NAME --dir build

# Set up environment variables in Netlify
echo "Setting up environment variables..."
netlify env:set FIREBASE_SERVICE_ACCOUNT "$(cat firebase-service-account.json)" --auth $NETLIFY_AUTH_TOKEN
netlify env:set FIREBASE_DATABASE_URL "https://market-data-collector.firebaseio.com" --auth $NETLIFY_AUTH_TOKEN
netlify env:set FIREBASE_STORAGE_BUCKET "market-data-collector.appspot.com" --auth $NETLIFY_AUTH_TOKEN
netlify env:set NETLIFY_URL "https://market-data-collector.netlify.app" --auth $NETLIFY_AUTH_TOKEN

# Enable scheduled functions
echo "Enabling scheduled functions..."
netlify functions:create --name collect-market-data --scheduled "0 * * * *" --auth $NETLIFY_AUTH_TOKEN

echo "Deployment completed successfully!"
echo "Your application is now available at: https://market-data-collector.netlify.app"
